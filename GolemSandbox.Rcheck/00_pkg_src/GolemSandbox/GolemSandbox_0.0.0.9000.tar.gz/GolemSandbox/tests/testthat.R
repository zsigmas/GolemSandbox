library(testthat)
library(GolemSandbox)

test_check("GolemSandbox")
